plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ai3dstorystudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.ai3dstorystudio"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
    }
}


dependencies {
    implementation("androidx.activity:activity-ktx:1.10.0")
}
