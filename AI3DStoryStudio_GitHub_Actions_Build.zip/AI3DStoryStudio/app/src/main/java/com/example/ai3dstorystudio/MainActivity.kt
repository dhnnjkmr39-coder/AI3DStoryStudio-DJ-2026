package com.example.ai3dstorystudio

import android.annotation.SuppressLint
import android.content.Intent
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingText: String = ""

    private val createTextFile = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(pendingText.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "TXT file saved", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Could not save file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val openImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) webView.evaluateJavascript("window.onReferenceImageSelected && window.onReferenceImageSelected('${uri}')", null)
    }

    inner class AndroidBridge {
        @JavascriptInterface fun saveTextFile(filename: String, content: String) {
            runOnUiThread {
                pendingText = content
                val safe = filename.replace(Regex("[^a-zA-Z0-9._-]"), "_").ifBlank { "AI_3D_Story_Prompt.txt" }
                createTextFile.launch(safe)
            }
        }
        @JavascriptInterface fun copyText(content: String) {
            runOnUiThread {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("AI 3D Story Prompt", content))
                Toast.makeText(this@MainActivity, "Prompt copied", Toast.LENGTH_SHORT).show()
            }
        }
        @JavascriptInterface fun shareText(content: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, content)
                }
                startActivity(Intent.createChooser(send, "Share your story prompt"))
            }
        }
        @JavascriptInterface fun showToast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(100), Toast.LENGTH_SHORT).show() }
        }
        @JavascriptInterface fun callAiBackend(endpoint: String, payload: String) {
            if (!endpoint.startsWith("https://", ignoreCase = true) || endpoint.length > 2048 || payload.length > 1_000_000) {
                runOnUiThread { webView.evaluateJavascript("window.onAiBackendResult && window.onAiBackendResult(false, 'Use a valid HTTPS backend URL and a smaller request.')", null) }
                return
            }
            Thread {
                var connection: HttpURLConnection? = null
                try {
                    connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 20000
                        readTimeout = 90000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("Accept", "application/json")
                    }
                    connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(1_000_000) } ?: ""
                    val ok = status in 200..299
                    val jsOk = if (ok) "true" else "false"
                    val jsResponse = JSONObject.quote(response.ifBlank { "HTTP $status" })
                    runOnUiThread { webView.evaluateJavascript("window.onAiBackendResult && window.onAiBackendResult($jsOk, $jsResponse)", null) }
                } catch (e: Exception) {
                    val message = JSONObject.quote(e.message ?: "Network request failed")
                    runOnUiThread { webView.evaluateJavascript("window.onAiBackendResult && window.onAiBackendResult(false, $message)", null) }
                } finally {
                    connection?.disconnect()
                }
            }.start()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.myWebView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val url = request.url
                if (url.scheme == "file" && url.path?.startsWith("/android_asset/") == true) return false
                if (url.scheme == "https" || url.scheme == "http") {
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url.toString())))
                        true
                    } catch (_: Exception) { true }
                }
                return true
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }
}
