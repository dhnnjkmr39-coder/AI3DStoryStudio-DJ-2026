import http from 'node:http';

const PORT = Number(process.env.PORT || 8787);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const API_VERSION = process.env.GEMINI_API_VERSION || 'v1beta';
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 12;
const requestCounts = new Map();

function send(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer'
  });
  res.end(JSON.stringify(body));
}

function makePrompt(b) {
  const c = b.character || {};
  const v = b.voice || {};
  return `You are the senior story director and prompt engineer for AI 3D Story Studio (Dj). Create a complete, production-ready cinematic story package using the supplied brief.\n\n` +
`PROJECT: ${b.title || 'Untitled Story'}\nSTORY / TOPIC: ${b.story || 'Develop an engaging story from the title.'}\nDURATION: ${b.durationMinutes || 1} minute(s)\nSCENES: ${b.sceneCount || 6}, exactly 10 seconds each\nFORMAT: ${b.aspectRatio || '9:16'}\nVISUAL STYLE: ${b.visualStyle || 'Realistic 2D Cinematic'}\nCHARACTER LOCK: Name ${c.name || 'Main Character'}; age ${c.age || 'as appropriate'}; appearance/costume ${c.appearance || 'define once and keep identical'}; VFX ${c.vfx || 'story appropriate'}\nVOICE LOCK: Profile ${v.profile || 'VOICE_LOCK_01'}; language ${v.language || 'Hindi'}; tone ${v.tone || 'cinematic'}; speed ${v.speed || 'natural'}\nBRAND: ${b.brand || 'Untold Bharat'}\nNO WATERMARK: ${b.noWatermark !== false}\nEXTRA INSTRUCTIONS: ${b.extraInstructions || 'None'}\n\n` +
`OUTPUT RULES:\n1. Write in ${b.outputLanguage || 'Hindi'}, while keeping image/video prompts clear and generator-ready (English is acceptable for prompts).\n2. Start with a powerful viewer hook and maintain a coherent beginning, middle and ending.\n3. Give exactly ${b.sceneCount || 6} numbered scenes, each exactly 10 seconds.\n4. For EVERY scene include: time range, story beat, concise voiceover, detailed image prompt, detailed 10-second video/motion prompt, camera movement, lighting, sound design, transition and continuity notes.\n5. Lock the character's face, age, hair, costume, body proportions and accessories across every scene. Lock narrator voice identity, accent, pitch and delivery.\n6. Avoid invented historical facts. Clearly distinguish documented history from legend or mythology when relevant.\n7. Include a final editing checklist and a short engaging audience CTA.\n8. Do not claim to generate images or video files; return text production prompts only.`;
}

const server = http.createServer(async (req, res) => {
  if (req.url === '/health' && req.method === 'GET') return send(res, 200, { ok: true, service: 'AI 3D Story Studio Gemini backend' });
  if (req.url !== '/generate' || req.method !== 'POST') return send(res, 404, { error: 'Not found' });
  if (!API_KEY) return send(res, 503, { error: 'Server is missing GEMINI_API_KEY environment secret.' });

  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const entry = requestCounts.get(ip);
  if (!entry || now - entry.start >= WINDOW_MS) requestCounts.set(ip, { start: now, count: 1 });
  else if (++entry.count > MAX_REQUESTS_PER_WINDOW) return send(res, 429, { error: 'Rate limit reached. Please wait one minute.' });

  try {
    let raw = '';
    for await (const chunk of req) {
      raw += chunk;
      if (raw.length > 1_000_000) return send(res, 413, { error: 'Request too large.' });
    }
    const brief = JSON.parse(raw || '{}');
    const duration = Number(brief.durationMinutes || 1);
    if (!Number.isInteger(duration) || duration < 1 || duration > 10) return send(res, 400, { error: 'durationMinutes must be between 1 and 10.' });
    if (typeof brief.story !== 'string' || brief.story.length > 30_000) return send(res, 400, { error: 'Story text is missing or too long.' });

    const url = `https://generativelanguage.googleapis.com/${API_VERSION}/models/${encodeURIComponent(MODEL)}:generateContent`;
    const upstream = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': API_KEY },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: makePrompt(brief) }] }],
        generationConfig: { temperature: 0.75, maxOutputTokens: 24576 }
      }),
      signal: AbortSignal.timeout(90_000)
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const message = data?.error?.message || `Gemini API returned HTTP ${upstream.status}`;
      return send(res, upstream.status >= 500 ? 502 : upstream.status, { error: message });
    }
    const text = (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('\n').trim();
    if (!text) return send(res, 502, { error: 'Gemini returned an empty response. Try again.' });
    return send(res, 200, { text, model: MODEL });
  } catch (error) {
    return send(res, 500, { error: error?.name === 'TimeoutError' ? 'AI request timed out. Please try again.' : 'Could not process the AI request.' });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`AI 3D Story Studio backend listening on port ${PORT}; model=${MODEL}`);
});
