# AI 3D Story Studio — Cloudflare Worker Deployment (Hindi)

यह backend Gemini API key को Android APK से बाहर रखता है। Cloudflare Worker secret में key सेव होगी।

## 1) जरूरी अकाउंट
- Cloudflare account: https://dash.cloudflare.com/sign-up
- Google AI Studio: https://aistudio.google.com/app/apikey

Cloudflare Workers का Free plan उपलब्ध है। वर्तमान प्रकाशित सीमा 100,000 requests/day है; यह केवल Worker hosting/request quota है। Gemini model की अपनी अलग quota/rate limits और संभावित billing हो सकती है।

## 2) Gemini API key बनाना
1. Google AI Studio के API Keys पेज पर जाएँ।
2. Create API key चुनें और key को निजी रखें।
3. Key को WhatsApp, ChatGPT chat, GitHub या Android app में paste/commit न करें।

## 3) Worker deploy करना — Dashboard वाला आसान तरीका
1. Cloudflare Dashboard खोलें: https://dash.cloudflare.com/
2. **Workers & Pages** खोलें → **Create** → **Create Worker**.
3. Worker का नाम `ai-3d-story-studio-api` रखें और Deploy करें।
4. Deploy होने के बाद **Edit code** खोलें। इस प्रोजेक्ट की `src/index.js` का पूरा code वहाँ paste करें और **Deploy** दबाएँ।
5. Worker → **Settings** → **Variables and Secrets** → **Add** → Type **Secret** चुनें।
6. Name `GEMINI_API_KEY` रखें, Google AI Studio वाली key Value में paste करें, Save/Deploy करें।
7. उसी पेज पर Text variables जोड़ें:
   - `GEMINI_MODEL` = `gemini-2.5-flash`
   - `GEMINI_API_VERSION` = `v1beta`
   फिर Deploy करें।
8. Worker का URL ऐसा मिलेगा: `https://ai-3d-story-studio-api.<your-subdomain>.workers.dev`

## 4) Endpoint test
ब्राउज़र में यह खोलें:
`https://ai-3d-story-studio-api.<your-subdomain>.workers.dev/health`

Expected response:
`{"ok":true,"service":"AI 3D Story Studio Gemini Worker"}`

## 5) Android app में URL सेट करें
App खोलें → **Real AI Connection** → **SECURE BACKEND HTTPS URL** में यह डालें:
`https://ai-3d-story-studio-api.<your-subdomain>.workers.dev/generate`
फिर **Generate with Real AI** दबाएँ।

## 6) Command-line deploy (वैकल्पिक)
इस folder में terminal खोलें:
```bash
npm install --save-dev wrangler
npx wrangler login
npx wrangler secret put GEMINI_API_KEY
npx wrangler deploy
```
जब prompt आए, Gemini key terminal में paste करें। `wrangler.toml` model/version variables सेट کرتا है।

## सुरक्षा / लागत نوٹس
- API Key केवल Cloudflare Worker Secret में रखें; ऐप में नहीं।
- Worker में basic per-isolate rate limiting है, लेकिन यह पूर्ण authentication या मजबूत global abuse protection नहीं है। Public launch से पहले user authentication और Cloudflare rate limiting/WAF rules जोड़ें।
- Free Worker hosting का मतलब unlimited/free AI generation नहीं है। Gemini quota, model availability और billing आपके Google project/account पर निर्भर हैं। Google AI Studio में मौजूदा limits जाँचें।
- API Key कभी भी इस चैट में न भेजें।
