const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 10;
const MAX_BODY_BYTES = 200_000;
const rateBuckets = new Map();

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
      'referrer-policy': 'no-referrer',
      ...extraHeaders,
    },
  });
}

function corsHeaders(origin) {
  // Android's native HttpURLConnection does not require CORS. These headers
  // also allow controlled browser testing; no credentialed cross-origin use.
  const allowed = origin && (origin.startsWith('https://') || origin === 'null') ? origin : '*';
  return {
    'access-control-allow-origin': allowed,
    'access-control-allow-methods': 'POST, GET, OPTIONS',
    'access-control-allow-headers': 'content-type',
    'vary': 'Origin',
  };
}

function rateLimited(request) {
  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  const now = Date.now();
  const old = rateBuckets.get(ip);
  if (!old || now - old.start >= WINDOW_MS) {
    rateBuckets.set(ip, { start: now, count: 1 });
    return false;
  }
  old.count += 1;
  return old.count > MAX_REQUESTS_PER_WINDOW;
}

function makePrompt(b) {
  const c = b.character || {};
  const v = b.voice || {};
  const duration = Number(b.durationMinutes || 1);
  const sceneCount = duration * 6;
  return `You are the senior story director and prompt engineer for AI 3D Story Studio (Dj). Create a complete, production-ready cinematic story package using the supplied brief.\n\n` +
    `PROJECT: ${b.title || 'Untitled Story'}\nSTORY / TOPIC: ${b.story || 'Develop an engaging story from the title.'}\nDURATION: ${duration} minute(s)\nSCENES: exactly ${sceneCount}, each exactly 10 seconds\nFORMAT: ${b.aspectRatio || '9:16'}\nVISUAL STYLE: ${b.visualStyle || 'Realistic 2D Cinematic'}\n` +
    `CHARACTER LOCK: Name ${c.name || 'Main Character'}; age ${c.age || 'as appropriate'}; appearance/costume ${c.appearance || 'define once and keep identical'}; VFX ${c.vfx || 'story appropriate'}\n` +
    `VOICE LOCK: Profile ${v.profile || 'VOICE_LOCK_01'}; language ${v.language || 'Hindi'}; tone ${v.tone || 'cinematic'}; speed ${v.speed || 'natural'}\n` +
    `BRAND: ${b.brand || 'Untold Bharat'}\nNO WATERMARK: ${b.noWatermark !== false}\nEXTRA INSTRUCTIONS: ${b.extraInstructions || 'None'}\n\n` +
    `OUTPUT RULES:\n1. Write in ${b.outputLanguage || 'Hindi'}, with clear generator-ready image/video prompts (English is acceptable for prompts).\n` +
    `2. Start with a powerful viewer hook and maintain coherent beginning, middle and ending.\n` +
    `3. Give exactly ${sceneCount} numbered scenes, each exactly 10 seconds.\n` +
    `4. For every scene include time range, story beat, voiceover, detailed image prompt, 10-second video/motion prompt, camera movement, lighting, sound design, transition and continuity notes.\n` +
    `5. Keep character face, age, hair, costume, proportions and accessories consistent. Keep narrator voice identity, accent, pitch and delivery consistent.\n` +
    `6. Do not invent historical facts. Distinguish documented history from legend or mythology.\n` +
    `7. Include a final editing checklist and audience CTA. Return text prompts only; do not claim to create image/video files.`;
}

export default {
  async fetch(request, env) {
    const cors = corsHeaders(request.headers.get('Origin'));
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (request.method === 'GET' && url.pathname === '/health') {
      return json({ ok: true, service: 'AI 3D Story Studio Gemini Worker' }, 200, cors);
    }
    if (request.method !== 'POST' || url.pathname !== '/generate') {
      return json({ error: 'Not found. Use POST /generate or GET /health.' }, 404, cors);
    }
    if (!env.GEMINI_API_KEY) return json({ error: 'Server is not configured: GEMINI_API_KEY secret is missing.' }, 503, cors);
    if (rateLimited(request)) return json({ error: 'Rate limit reached. Please wait one minute and try again.' }, 429, cors);

    try {
      const raw = await request.text();
      if (new TextEncoder().encode(raw).length > MAX_BODY_BYTES) return json({ error: 'Request too large.' }, 413, cors);
      const brief = JSON.parse(raw || '{}');
      const duration = Number(brief.durationMinutes || 1);
      if (!Number.isInteger(duration) || duration < 1 || duration > 10) {
        return json({ error: 'durationMinutes must be between 1 and 10.' }, 400, cors);
      }
      if (typeof brief.story !== 'string' || brief.story.length > 30_000) {
        return json({ error: 'Story text is missing or too long.' }, 400, cors);
      }

      const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
      const apiVersion = env.GEMINI_API_VERSION || 'v1beta';
      const endpoint = `https://generativelanguage.googleapis.com/${apiVersion}/models/${encodeURIComponent(model)}:generateContent`;
      const upstream = await fetch(endpoint, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: makePrompt(brief) }] }],
          generationConfig: { temperature: 0.75, maxOutputTokens: 24576 },
        }),
        signal: AbortSignal.timeout(90_000),
      });
      const data = await upstream.json().catch(() => ({}));
      if (!upstream.ok) {
        const message = data?.error?.message || `Gemini API returned HTTP ${upstream.status}`;
        return json({ error: message }, upstream.status >= 500 ? 502 : upstream.status, cors);
      }
      const text = (data?.candidates?.[0]?.content?.parts || []).map((part) => part.text || '').join('\n').trim();
      if (!text) return json({ error: 'Gemini returned an empty response. Please try again.' }, 502, cors);
      return json({ text, model }, 200, cors);
    } catch (error) {
      const message = error?.name === 'TimeoutError' ? 'AI request timed out. Please try again.' : 'Could not process the AI request.';
      return json({ error: message }, 500, cors);
    }
  },
};
