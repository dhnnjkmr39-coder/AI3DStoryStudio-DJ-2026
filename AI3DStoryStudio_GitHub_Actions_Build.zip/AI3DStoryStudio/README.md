# AI 3D Story Studio (Dj)

Android Studio project for package `com.example.ai3dstorystudio`.

## Features
- Offline-first single-file HTML/CSS/JavaScript interface (no CDN dependencies)
- Cinematic dark navy, gold and blue design
- 9:16 Shorts and 16:9 video formats
- 1–10 minute duration with six 10-second scenes per minute
- Story word count and scene count
- Character consistency lock and voice consistency lock
- Master prompt generation with voiceover, image prompt, motion prompt and sound design for each scene
- Copy, native Android TXT save, Android share sheet, sample story and reset
- Android back navigation

## Open in Android Studio
Open this folder (`AI3DStoryStudio`) in Android Studio. Use JDK 17 and allow Gradle sync. The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. Android Studio may install the required SDK 35 platform if missing.

## Build APK
After Gradle sync: Build > Build Bundle(s) / APK(s) > Build APK(s). For distribution, use Build > Generate Signed Bundle / APK and create a signing key. Keep the keystore safe for future updates.

## Notes
This project is a prompt-generation studio; it does not call an external AI model or generate actual video. The generated prompts can be copied into your preferred AI tools. The native TXT export uses Android's document picker.


## Build and verification status
- This is an Android Studio source project, not a prebuilt APK.
- Open the `AI3DStoryStudio` folder in Android Studio and allow Gradle Sync to finish.
- Select **Build > Build Bundle(s) / APK(s) > Build APK(s)** to create a debug APK.
- The current execution environment does not include the Android SDK or Gradle, so an APK build and device test have not been performed here.
- The story tool generates a structured production prompt from the user's inputs; it does not call an external generative-AI service.


## Secure AI backend integration (v1.1)

The Android app now includes an HTTPS-only backend connector and a **Generate with Real AI** action. It does not contain a provider API key. Enter the URL of a backend you control; that backend is responsible for authenticating to Gemini or another model provider and must return JSON in this shape:

```json
{ "text": "Your complete generated story and scene-by-scene production plan" }
```

The app sends a JSON brief containing the story topic, duration, scene count, aspect ratio, character lock, voice lock, brand, and production instructions. The connector accepts HTTPS endpoints only, uses connection/read timeouts, and limits request/response size. **A backend service and provider API key are still required** before real AI generation can work. Do not put a provider API key in the APK or in the backend URL field.

Suggested provider for the first backend: Google Gemini (Google AI Studio API key stored only as a server-side environment secret). The backend endpoint and deployment are not included in this Android project, so no live AI call has been performed.

## Included Gemini backend starter

A minimal Node.js backend starter is in `backend-gemini/`. It uses Node's built-in `fetch` and HTTP server, so no npm package installation is required. Run it on a server with Node.js 20+ after setting `GEMINI_API_KEY` as a server environment secret. The example model is configurable through `GEMINI_MODEL`; confirm model availability and quota in your Google AI Studio project. Put the backend behind HTTPS before entering its URL in the Android app. The starter includes basic per-IP rate limiting and request validation; for a public production launch, add user authentication, stronger abuse controls, monitoring, and a managed HTTPS reverse proxy. Never commit the real `.env` file or embed the Gemini key in the Android app.

## Cloudflare Workers deployment (v1.2)
A deploy-ready Cloudflare Worker version of the Gemini backend is included in `backend-cloudflare/`. Read `backend-cloudflare/README_DEPLOY_HI.md` for the dashboard-based Hindi deployment steps. Store `GEMINI_API_KEY` as a Cloudflare **Secret**, never in the Android app or source code. Cloudflare's Free Workers plan has a published daily request allowance, but Gemini model quotas and charges are separate. A deployment still requires the account owner to sign in, create the secret and deploy; this project archive is not itself a live hosted endpoint.

## GitHub Actions: build a debug APK without Android Studio

1. Upload the complete contents of this project folder to a GitHub repository (keep the `.github/workflows/android-apk.yml` file and its folders).
2. Open the repository's **Actions** tab and select **Build Android APK**.
3. Press **Run workflow** if it has not started automatically after a push.
4. When the run finishes successfully, open that run and download the `AI3DStoryStudio-debug-apk` artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

This workflow builds a debug APK. It does not sign a production release. A successful cloud build has not yet been confirmed.
